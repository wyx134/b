const https = require('https');
const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');

console.log('正在启动DeepSeek语音助手服务器...');

// 生成自签名证书（如果没有的话）
function generateSelfSignedCert() {
  try {
    const selfsigned = require('selfsigned');
    console.log('正在生成自签名证书...');
    const attrs = [{ name: 'commonName', value: 'localhost' }];
    const opts = {
      keySize: 2048,
      days: 365,
      algorithm: 'sha256'
    };
    const pems = selfsigned.generate(attrs, opts);
    console.log('✅ 证书生成成功');
    return pems;
  } catch (error) {
    console.error('❌ 证书生成失败:', error.message);
    process.exit(1);
  }
}

// 检查是否有证书文件，如果没有就生成
let options = {};
try {
  if (fs.existsSync('key.pem') && fs.existsSync('cert.pem')) {
    options = {
      key: fs.readFileSync('key.pem'),
      cert: fs.readFileSync('cert.pem')
    };
    console.log('✅ 使用现有的证书文件');
  } else {
    throw new Error('证书文件不存在');
  }
} catch (error) {
  console.log('📝 生成新的自签名证书...');
  const pems = generateSelfSignedCert();
  options = {
    key: pems.private,
    cert: pems.cert
  };
  // 保存证书文件供以后使用
  fs.writeFileSync('key.pem', pems.private);
  fs.writeFileSync('cert.pem', pems.cert);
  console.log('✅ 证书文件已保存');
}

// 支持的MIME类型
const mimeTypes = {
  '.html': 'text/html',
  '.js': 'text/javascript',
  '.css': 'text/css',
  '.json': 'application/json',
  '.png': 'image/png',
  '.jpg': 'image/jpg',
  '.gif': 'image/gif',
  '.svg': 'image/svg+xml',
  '.wav': 'audio/wav',
  '.mp4': 'video/mp4',
  '.woff': 'application/font-woff',
  '.ttf': 'application/font-ttf',
  '.eot': 'application/vnd.ms-fontobject',
  '.otf': 'application/font-otf',
  '.wasm': 'application/wasm'
};

// 创建HTTPS服务器
const httpsServer = https.createServer(options, (req, res) => {
  console.log(`📨 HTTPS请求: ${req.method} ${req.url}`);
  
  // 解析请求路径
  let filePath = '.' + req.url;
  if (filePath === './') {
    filePath = './index.html';
  }

  const extname = String(path.extname(filePath)).toLowerCase();
  const contentType = mimeTypes[extname] || 'application/octet-stream';

  fs.readFile(filePath, (error, content) => {
    if (error) {
      if (error.code === 'ENOENT') {
        // 文件不存在，返回404
        res.writeHead(404, { 'Content-Type': 'text/html' });
        res.end('<h1>404 - 文件未找到</h1>', 'utf-8');
      } else {
        // 服务器错误
        res.writeHead(500);
        res.end('服务器错误: ' + error.code + ' ..\n');
      }
    } else {
      // 成功返回文件
      res.writeHead(200, { 'Content-Type': contentType });
      res.end(content, 'utf-8');
    }
  });
});

// 创建HTTP服务器用于重定向到HTTPS
const httpServer = http.createServer((req, res) => {
  const httpsUrl = 'https://' + req.headers.host.replace(/:\d+$/, '') + ':8443' + req.url;
  res.writeHead(301, { 
    "Location": httpsUrl
  });
  res.end();
});

// 启动HTTP服务器（端口8080）
httpServer.listen(8080, 'localhost', () => {
  console.log('🌐 HTTP重定向服务器运行在: http://localhost:8080');
});

// 启动HTTPS服务器（端口8443）
httpsServer.listen(8443, 'localhost', () => {
  console.log('🔐 HTTPS服务器运行在: https://localhost:8443');
  console.log('\n✨ 请按以下步骤访问:');
  console.log('1. 打开浏览器访问: https://localhost:8443');
  console.log('2. 由于使用自签名证书，浏览器会显示"不安全"警告');
  console.log('3. 点击"高级" -> "继续前往localhost（不安全）"');
  console.log('4. 首次使用时，请确保在麦克风权限弹窗中选择"始终允许"');
  console.log('\n🛑 按 Ctrl+C 停止服务器\n');
});

// 优雅关闭
process.on('SIGINT', () => {
  console.log('\n👋 正在关闭服务器...');
  httpsServer.close(() => {
    console.log('✅ HTTPS服务器已关闭');
    httpServer.close(() => {
      console.log('✅ HTTP服务器已关闭');
      process.exit(0);
    });
  });
});